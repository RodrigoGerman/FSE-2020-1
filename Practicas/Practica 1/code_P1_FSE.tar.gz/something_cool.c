#include <stdio.h>

int main(int argc, char **argv) {
	int i=0;
	for(i = 1;i < 16;i++){
		printf("#%d FSE2020-1 German Lopez Rodrigo\n",i);
	}	
	printf("Hello world!\n");
	return 0;
}
